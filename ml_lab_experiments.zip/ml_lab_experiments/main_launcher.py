"""
main_launcher.py
-----------------
Single entry point for all 5 ML lab experiments.

Run this file (F5 in VS Code, or `python main_launcher.py` in a terminal).
A window with 5 buttons will appear. Each button opens a separate
window (Toplevel) containing the full graphical user interface for
that experiment. No command-line input is required anywhere -- every
input the teacher needs to give is a slider, dropdown, radio button
or text box inside the window.

Author: NomanStd
"""

import tkinter as tk
from tkinter import ttk

# Each experiment lives in its own file inside experiments/ and exposes
# a single function `open_window(parent)` that builds its GUI in a
# Toplevel window.
from experiments import knn_gui
from experiments import svm_gui
from experiments import kmeans_gui
from experiments import decision_tree_gui
from experiments import perceptron_apple_orange_gui


class LauncherApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ML Lab Experiments - Launcher")
        self.root.geometry("480x420")
        self.root.resizable(False, False)

        title = tk.Label(
            root,
            text="Machine Learning Lab Experiments",
            font=("Segoe UI", 16, "bold"),
        )
        title.pack(pady=(20, 5))

        subtitle = tk.Label(
            root,
            text="Choose an experiment to open its graphical interface",
            font=("Segoe UI", 10),
            fg="#555555",
        )
        subtitle.pack(pady=(0, 20))

        button_config = [
            ("1. K-Nearest Neighbors (KNN) - Iris Classification", knn_gui.open_window),
            ("2. Support Vector Machine (SVM) - Iris Classification", svm_gui.open_window),
            ("3. K-Means Clustering", kmeans_gui.open_window),
            ("4. Decision Tree - Iris Classification", decision_tree_gui.open_window),
            ("5. Perceptron - Apple vs Orange (Hagan Ch.4)", perceptron_apple_orange_gui.open_window),
        ]

        style = ttk.Style()
        style.configure("Exp.TButton", font=("Segoe UI", 10), padding=10)

        for label, func in button_config:
            btn = ttk.Button(
                root,
                text=label,
                style="Exp.TButton",
                command=lambda f=func: f(self.root),
            )
            btn.pack(fill="x", padx=30, pady=6)

        footer = tk.Label(
            root,
            text="Each window is self-contained: dataset loading, training\n"
                 "and prediction all happen through on-screen controls.",
            font=("Segoe UI", 8),
            fg="#888888",
            justify="center",
        )
        footer.pack(pady=(20, 10))


if __name__ == "__main__":
    root = tk.Tk()
    app = LauncherApp(root)
    root.mainloop()
