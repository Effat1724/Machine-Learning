# ML Lab Experiments (5 Experiments, GUI-based)

This project implements **5 machine learning lab experiments**, each with
its own **graphical user interface (GUI)** — no command-line input is
required anywhere. The teacher (or anyone) interacts entirely through
sliders, dropdowns, buttons and text boxes.

## Experiments included

| # | Experiment | Dataset | File |
|---|------------|---------|------|
| 1 | K-Nearest Neighbors (KNN) | Iris (built into scikit-learn) | `experiments/knn_gui.py` |
| 2 | Support Vector Machine (SVM) | Iris (petal length/width) | `experiments/svm_gui.py` |
| 3 | K-Means Clustering | Synthetic 2D blobs (generated on the fly) | `experiments/kmeans_gui.py` |
| 4 | Decision Tree | Iris (built into scikit-learn) | `experiments/decision_tree_gui.py` |
| 5 | Perceptron: Apple vs Orange (Hagan, Ch. 4) | 2 hand-crafted patterns | `experiments/perceptron_apple_orange_gui.py` |

Step-by-step tutorial reports for each experiment (how the dataset is
read, how training works, how to run and read the GUI) are in the
`reports/` folder.

## How to run (VS Code)

1. **Unzip** this folder and open it in VS Code (`File > Open Folder...`).
2. Make sure you have **Python 3.9+** installed and selected as the
   interpreter (bottom-right corner of VS Code, or `Ctrl+Shift+P` ->
   "Python: Select Interpreter").
3. Open a terminal in VS Code (`` Ctrl+` ``) and install the required
   packages once:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the **launcher** — this opens ONE window with 5 buttons, one per
   experiment:
   ```bash
   python main_launcher.py
   ```
   (Or press `F5` in VS Code with `main_launcher.py` open.)
5. Click any button to open that experiment's own window. You can open
   several experiment windows at the same time.

No experiment ever asks for input in the terminal — every input
(numbers, dataset size, choices) is a widget inside the window that
opens.

## Project structure

```
ml_lab_experiments/
├── main_launcher.py              <- run this file
├── requirements.txt
├── experiments/
│   ├── knn_gui.py
│   ├── svm_gui.py
│   ├── kmeans_gui.py
│   ├── decision_tree_gui.py
│   └── perceptron_apple_orange_gui.py
└── reports/
    ├── 01_KNN_Tutorial.md
    ├── 02_SVM_Tutorial.md
    ├── 03_KMeans_Tutorial.md
    ├── 04_DecisionTree_Tutorial.md
    └── 05_Perceptron_AppleOrange_Tutorial.md
```

## Why Tkinter?

Tkinter ships with standard Python (no extra install needed), runs as a
**native desktop window** (not a browser page), and opens instantly
when you press Run in VS Code — this is the simplest way to satisfy
"must be a GUI, not a command line, and must run on our own laptop."

## Notes on the datasets

- **Iris dataset** (used by KNN, SVM, Decision Tree) is a classic,
  tiny, well-known dataset built directly into scikit-learn
  (`sklearn.datasets.load_iris`) — no external file or download is
  needed, so the project works offline and the reviewer can inspect the
  data instantly.
- **K-Means** generates its own synthetic 2D data on each run
  (`sklearn.datasets.make_blobs`) so the teacher can experiment with
  different data sizes and cluster counts live.
- **Perceptron (Apple vs Orange)** uses the textbook example from
  Hagan's *Neural Network Design*, Chapter 4: two sensor readings
  (shape, texture) and two training patterns (one apple, one orange).
  The perceptron learning rule is implemented from scratch (no
  scikit-learn) so every weight update can be shown step by step in the
  log box — useful if the teacher asks "explain what the code is
  doing."
