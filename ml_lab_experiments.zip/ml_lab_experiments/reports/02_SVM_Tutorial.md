# Tutorial Report: Support Vector Machine (SVM)

**File:** `experiments/svm_gui.py`
**Goal:** Classify iris flowers using an SVM, with a visible 2D decision
boundary, controlled entirely through a GUI.

## 1. What is SVM?

A Support Vector Machine finds the boundary (hyperplane) that best
separates classes by maximizing the margin between the boundary and the
closest points of each class ("support vectors"). With a kernel (e.g.
`rbf`), it can also draw non-linear boundaries by implicitly mapping
data into a higher-dimensional space.

## 2. Step-by-step: how the dataset is read

1. We again use `sklearn.datasets.load_iris()`.
2. To be able to **draw** the decision boundary on a normal 2D plot, we
   deliberately use only **2 of the 4 features**: petal length and
   petal width (columns index 2 and 3). These two features separate the
   3 species very well on their own.
   ```python
   data = load_iris()
   X = data.data[:, 2:4]   # petal length, petal width
   y = data.target
   ```

## 3. Step-by-step: how training works

1. **Split the data**: 70% train / 30% test, stratified by class.
2. **Choose kernel and C** in the GUI:
   - `kernel` = `linear`, `rbf`, or `poly` (dropdown).
   - `C` = regularization strength (text box, default 1.0). A larger C
     tries harder to classify every training point correctly (can
     overfit); a smaller C allows more misclassification for a wider
     margin (can underfit).
3. **Fit the model**:
   ```python
   model = SVC(kernel=kernel, C=C)
   model.fit(X_train, y_train)
   ```
4. **Evaluate**: accuracy on the test set is computed and displayed.
5. **Visualize**: a mesh grid is created over the feature space, the
   model predicts a class for every point in the grid, and the result
   is drawn as colored regions (the decision boundary) with the actual
   data points overlaid.

## 4. How to run and use the GUI

1. Launch `python main_launcher.py` and click **"2. Support Vector
   Machine (SVM) - Iris Classification."**
2. Pick a **kernel** from the dropdown and type a **C** value.
3. Click **"Train & Plot Boundary."** The window shows the accuracy and
   a colored plot: each color region is a predicted class, and the dots
   are the actual flowers, colored by their true species.
4. To classify a new flower, type its petal length & petal width and
   click **"Predict."**

## 5. Things the teacher might ask about the code

- **"Why only 2 features here, unlike KNN which used all 4?"** — So the
  decision boundary can be drawn on a normal 2D chart. With 4 features
  we'd need a 4-dimensional plot, which isn't visualizable directly.
- **"What is the effect of the `rbf` kernel vs `linear`?"** — `linear`
  can only draw a straight-line boundary; `rbf` can draw curved,
  flexible boundaries, useful when classes aren't linearly separable.
- **"What is C controlling exactly?"** — It's the trade-off in the SVM
  optimization between a wide margin and fewer misclassified training
  points. Try C = 0.1 vs C = 100 in the GUI and see the boundary change
  shape.
