# Tutorial Report: Decision Tree

**File:** `experiments/decision_tree_gui.py`
**Goal:** Classify iris flowers using a Decision Tree, with the tree
structure visualized as a diagram, controlled entirely through a GUI.

## 1. What is a Decision Tree?

A Decision Tree classifies data by asking a sequence of yes/no
questions about the features (e.g. "is petal length ≤ 2.45?"), starting
from a root question and branching down to leaves that give a final
class prediction. It is trained by repeatedly picking the feature/
threshold split that best separates the classes (using a purity measure
such as Gini impurity).

## 2. Step-by-step: how the dataset is read

Same as the KNN experiment — `sklearn.datasets.load_iris()` gives
150 samples, 4 features, 3 classes, no external file needed:
```python
data = load_iris()
X = data.data
y = data.target
```

## 3. Step-by-step: how training works

1. **Split the data**: 70% train / 30% test, stratified by class.
2. **Choose Max Depth** in the GUI (a slider, 1–8). This limits how
   many yes/no questions deep the tree is allowed to go — a way to
   prevent overfitting.
3. **Fit the model**:
   ```python
   model = DecisionTreeClassifier(max_depth=depth, random_state=42)
   model.fit(X_train, y_train)
   ```
4. **Evaluate**: accuracy on the held-out test set is computed.
5. **Visualize**: `sklearn.tree.plot_tree()` draws the actual learned
   tree — each box shows the split condition, the Gini impurity, the
   number of samples, and the predicted class at that node.

## 4. How to run and use the GUI

1. Launch `python main_launcher.py` and click **"4. Decision Tree -
   Iris Classification."**
2. Move the **Max Depth slider**.
3. Click **"Train & Show Tree."** The window shows the test accuracy
   and a diagram of the trained tree.
4. To classify a new flower, type its 4 measurements and click
   **"Predict."**

## 5. Things the teacher might ask about the code

- **"What does a node's Gini value mean?"** — It measures how "mixed"
  the classes are at that node; 0 means the node is perfectly pure
  (only one class present), higher values mean more mixing.
- **"Why limit the depth?"** — A very deep tree can memorize the
  training data exactly (perfect training accuracy) but generalize
  poorly to new data (overfitting). Try Max Depth = 1 vs Max Depth = 8
  in the GUI and compare test accuracy and how the tree looks.
- **"How is a split chosen?"** — For every feature and every possible
  threshold, the algorithm measures how much that split would reduce
  Gini impurity, and picks the single best split at each node
  (a greedy, top-down strategy).
