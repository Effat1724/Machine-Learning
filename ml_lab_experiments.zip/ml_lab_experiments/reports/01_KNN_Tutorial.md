# Tutorial Report: K-Nearest Neighbors (KNN)

**File:** `experiments/knn_gui.py`
**Goal:** Classify iris flowers into 3 species (setosa, versicolor,
virginica) using the K-Nearest Neighbors algorithm, controlled entirely
through a GUI.

## 1. What is KNN?

KNN is a "lazy learning" algorithm: it does not build an explicit model
during training. To classify a new point, it looks at the **K closest
points** (by distance) in the training data and assigns the majority
class among them.

## 2. Step-by-step: how the dataset is read

1. We use `sklearn.datasets.load_iris()`. This function returns the
   famous Iris dataset built directly into scikit-learn — 150 samples,
   4 numeric features per sample (sepal length, sepal width, petal
   length, petal width), and 3 possible classes.
   ```python
   from sklearn.datasets import load_iris
   data = load_iris()
   X = data.data          # shape (150, 4) - the 4 measurements
   y = data.target        # shape (150,)  - the species (0, 1, or 2)
   ```
2. No file reading or downloading is required — the dataset ships
   inside the scikit-learn package.

## 3. Step-by-step: how training works

1. **Split the data**: 70% of samples for training, 30% held out for
   testing, using `train_test_split(..., test_size=0.3, stratify=y)`.
   `stratify=y` makes sure all 3 species are proportionally represented
   in both splits.
2. **Scale the features**: KNN relies on distance, and the 4
   measurements are on different scales, so we apply
   `StandardScaler()` (mean 0, standard deviation 1) fit only on the
   training data, then applied to both train and test sets.
3. **Choose K**: the teacher picks K (1–15) using a slider in the GUI.
4. **Fit the model**:
   ```python
   model = KNeighborsClassifier(n_neighbors=k)
   model.fit(X_train_scaled, y_train)
   ```
5. **Evaluate**: predictions are made on the test set and compared to
   the true labels using `accuracy_score` and a confusion matrix.

## 4. How to run and use the GUI

1. Launch `python main_launcher.py` and click **"1. K-Nearest
   Neighbors (KNN) - Iris Classification."**
2. Move the **K slider** to the desired number of neighbors.
3. Click **"Train & Evaluate."** The window shows:
   - the test accuracy (as a percentage),
   - a confusion matrix plot (rows = true species, columns = predicted
     species; the diagonal shows correct predictions).
4. To classify a brand-new flower, type its 4 measurements into the
   text boxes at the bottom and click **"Predict."** The predicted
   species name appears immediately.

## 5. Things the teacher might ask about the code

- **"Why scale the features?"** — Because KNN measures Euclidean
  distance; if one feature has a much larger numeric range than
  another, it would dominate the distance calculation unfairly.
- **"What happens if K is even?"** — Ties are possible in theory;
  scikit-learn breaks ties by picking the class with the lowest index
  or the ordering of neighbors, so in practice we prefer odd K values
  for this 3-class problem, but the GUI allows any K from 1–15 for
  experimentation.
- **"What does a higher/lower K do?"** — Larger K smooths the decision
  boundary (less sensitive to noise but may blur class boundaries);
  smaller K is more sensitive to individual nearby points (can overfit
  to noise).
