# Tutorial Report: K-Means Clustering

**File:** `experiments/kmeans_gui.py`
**Goal:** Group unlabeled 2D points into K clusters, controlled
entirely through a GUI.

## 1. What is K-Means?

K-Means is an **unsupervised** algorithm (no labels are given). It
tries to split data into K groups so that points in the same group are
close to each other. It works by:
1. Randomly placing K "centroids."
2. Assigning every point to its nearest centroid.
3. Moving each centroid to the average position of its assigned
   points.
4. Repeating steps 2–3 until the centroids stop moving.

## 2. Step-by-step: how the "dataset" is read/generated

Unlike the other 4 experiments, K-Means here uses **synthetic data
generated on demand** rather than a fixed dataset file — this lets the
teacher experiment with different data sizes live.

```python
from sklearn.datasets import make_blobs
X, _ = make_blobs(n_samples=n_points, centers=max(k, 3),
                   n_features=2, cluster_std=1.0, random_state=42)
```

- `n_points`: how many 2D points to generate (controlled by a slider,
  50–1000).
- `centers`: how many "true" natural groups to scatter the points
  around (this is just for generating interesting data — the K-Means
  algorithm itself is never told this number).
- `random_state=42` makes the generated data reproducible.

## 3. Step-by-step: how training (clustering) works

1. The teacher chooses **K** (number of clusters K-Means should look
   for) using a slider (2–8).
2. Fit K-Means:
   ```python
   model = KMeans(n_clusters=k, n_init=10, random_state=42)
   labels = model.fit_predict(X)
   ```
   `n_init=10` means the algorithm is run 10 times with different
   random starting centroids and the best result (lowest inertia) is
   kept — this avoids bad results from an unlucky random start.
3. **Inertia** (within-cluster sum of squared distances to each point's
   centroid) is reported as a measure of how tightly grouped the
   clusters are — lower is generally better, but this must be balanced
   against choosing a sensible K.

## 4. How to run and use the GUI

1. Launch `python main_launcher.py` and click **"3. K-Means
   Clustering."**
2. Move the sliders for **number of data points** and **number of
   clusters (K)**.
3. Click **"Generate Data & Cluster."** The window shows:
   - the inertia value,
   - a scatter plot where each color is a cluster, and black "X" marks
     are the final cluster centers.
4. Change K or the number of points and click the button again to
   compare results — for example, try setting K much higher or lower
   than the actual number of visible clusters in the plot.

## 5. Things the teacher might ask about the code

- **"Why is K-Means called unsupervised?"** — Because `make_blobs`'s
  true group labels are thrown away (`_`) and never given to the
  `KMeans` model; it only sees `X` (positions), not any labels.
- **"How does K-Means decide where to put the first centroids?"** —
  scikit-learn uses `k-means++` initialization by default, which
  spreads initial centroids apart intelligently rather than picking
  them purely at random, improving convergence speed and quality.
- **"What happens if K doesn't match the real number of groups?"** —
  Demonstrate live: set K much smaller or larger than the visually
  apparent number of blobs and observe how clusters get merged or
  split.
