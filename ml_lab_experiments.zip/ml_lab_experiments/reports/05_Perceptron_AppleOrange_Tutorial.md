# Tutorial Report: Perceptron — Apple vs Orange Recognition
### (Hagan, *Neural Network Design*, Chapter 4)

**File:** `experiments/perceptron_apple_orange_gui.py`
**Goal:** Reproduce the classic apple-vs-orange perceptron example from
Hagan's textbook, implemented from scratch (no external ML library),
controlled entirely through a GUI.

## 1. What is a Perceptron?

A perceptron is the simplest artificial neuron. It computes a weighted
sum of its inputs plus a bias, then passes that sum through a
**hard-limit activation function**:

```
n = W·p + b
a = hardlim(n) =  +1  if n >= 0
                  -1  if n <  0
```

It learns using the **perceptron learning rule**: after seeing a
training pattern, if the output is wrong, the weights and bias are
nudged in the direction that would have made the answer correct.

```
error e = target t - output a
W_new = W_old + e * p        (p = input pattern)
b_new = b_old + e
```

## 2. Step-by-step: how the "dataset" is read

In Hagan's textbook example, a fruit sensor produces exactly two
measurements:
- **Shape**: +1 = round, −1 = elliptical/oval
- **Texture**: +1 = smooth, −1 = rough/textured

There are only two labeled training patterns (this is the standard
minimal example from the book, not a large dataset):

| Fruit  | Shape | Texture | Target |
|--------|-------|---------|--------|
| Orange | −1    | −1      | −1     |
| Apple  | +1    | +1      | +1     |

In code:
```python
P = np.array([[-1, -1], [1, 1]])   # patterns: orange, apple
T = np.array([-1, 1])              # targets
```

## 3. Step-by-step: how training works

1. Start with weights `W = [0, 0]` and bias `b = 0`.
2. For each training pattern (in order), compute:
   - `n = W·p + b`
   - `a = hardlim(n)`
   - `e = t - a`
3. If `e != 0`, update: `W = W + e*p`, `b = b + e`. If `e == 0`, the
   perceptron already got that pattern right — no update needed.
4. Repeat over the 2 patterns for multiple **epochs** until an entire
   epoch produces zero errors (the perceptron has converged).

The GUI's **"Train Perceptron (from scratch)"** button runs exactly
this loop and prints every single step (pattern seen, net value,
output, error, and any weight update) into a log box, so the whole
learning process is visible and explainable.

## 4. How to run and use the GUI

1. Launch `python main_launcher.py` and click **"5. Perceptron - Apple
   vs Orange (Hagan Ch.4)."**
2. Click **"Train Perceptron (from scratch)."** Watch the log box show
   each epoch, each pattern's net/output/error, and the final learned
   weights and bias.
3. In the **"Classify a new fruit"** section, choose Shape (Round/Oval)
   and Texture (Smooth/Rough) using the radio buttons.
4. Click **"Classify."** The GUI computes the net value with the
   trained weights and reports whether the perceptron thinks it's an
   Apple or an Orange.

## 5. Things the teacher might ask about the code

- **"Why does it converge so fast (1–2 epochs)?"** — Because there are
  only 2 training patterns and they are linearly separable (a single
  straight line/plane can separate them), which is exactly the
  condition under which the perceptron convergence theorem guarantees
  the rule will find a correct set of weights in a finite number of
  steps.
- **"What if we asked it to classify shape=+1, texture=-1 (round but
  rough)?"** — This pattern was never in the training data; the
  perceptron will still give an answer based on which side of its
  learned decision line the point falls on — a good live demo of how
  perceptrons generalize (or don't) to unseen combinations.
- **"Why is this implemented manually instead of using scikit-learn's
  `Perceptron` class?"** — To directly mirror Hagan's textbook
  derivation (`W_new = W_old + e*p^T`, `b_new = b_old + e`) step by
  step, and to make every weight update visible in the log for
  teaching/demonstration purposes.
