"""
kmeans_gui.py
-------------
Experiment 3: K-Means Clustering on synthetic 2D data.

What the GUI lets the teacher do:
1. Choose number of sample points and number of clusters with sliders.
2. Click "Generate Data & Cluster" -> random data is generated, K-Means
   is fit, and the resulting clusters (with centers marked as X) are
   plotted.
3. Inertia (within-cluster sum of squares) is shown as a numeric
   measure of clustering quality.
"""

import tkinter as tk
from tkinter import ttk

import numpy as np
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


class KMeansApp:
    def __init__(self, parent):
        self.win = tk.Toplevel(parent)
        self.win.title("Experiment 3: K-Means Clustering")
        self.win.geometry("760x640")

        self._build_widgets()

    def _build_widgets(self):
        top = tk.Frame(self.win)
        top.pack(fill="x", padx=15, pady=10)

        tk.Label(top, text="Number of data points:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w")
        self.n_points_var = tk.IntVar(value=300)
        tk.Scale(top, from_=50, to=1000, orient="horizontal", variable=self.n_points_var,
                 length=200).grid(row=0, column=1, padx=10)

        tk.Label(top, text="Number of clusters (K):", font=("Segoe UI", 10, "bold")).grid(row=1, column=0, sticky="w")
        self.k_var = tk.IntVar(value=4)
        tk.Scale(top, from_=2, to=8, orient="horizontal", variable=self.k_var,
                 length=200).grid(row=1, column=1, padx=10)

        run_btn = ttk.Button(top, text="Generate Data & Cluster", command=self.run_clustering)
        run_btn.grid(row=0, column=2, rowspan=2, padx=15)

        self.result_label = tk.Label(self.win, text="Click the button above to run K-Means.",
                                      font=("Segoe UI", 10), fg="#333333")
        self.result_label.pack(pady=5)

        self.plot_frame = tk.Frame(self.win)
        self.plot_frame.pack(fill="both", expand=True, padx=15, pady=5)

    def run_clustering(self):
        n_points = self.n_points_var.get()
        k = self.k_var.get()

        # Step 1: generate synthetic dataset with some "true" cluster structure
        X, _ = make_blobs(n_samples=n_points, centers=max(k, 3), n_features=2,
                          cluster_std=1.0, random_state=42)

        # Step 2: fit K-Means
        model = KMeans(n_clusters=k, n_init=10, random_state=42)
        labels = model.fit_predict(X)

        self.result_label.config(
            text=f"K = {k}, points = {n_points}  |  Inertia (WCSS) = {model.inertia_:.2f}"
        )

        self._plot_clusters(X, labels, model.cluster_centers_)

    def _plot_clusters(self, X, labels, centers):
        for widget in self.plot_frame.winfo_children():
            widget.destroy()

        fig, ax = plt.subplots(figsize=(5.5, 4.5))
        scatter = ax.scatter(X[:, 0], X[:, 1], c=labels, cmap="tab10", s=25, alpha=0.8)
        ax.scatter(centers[:, 0], centers[:, 1], c="black", marker="X", s=150, label="Centroids")
        ax.set_title("K-Means Clustering Result")
        ax.set_xlabel("Feature 1")
        ax.set_ylabel("Feature 2")
        ax.legend()
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        plt.close(fig)


def open_window(parent):
    KMeansApp(parent)
