"""
knn_gui.py
----------
Experiment 1: K-Nearest Neighbors (KNN) classification on the Iris dataset.

What this GUI lets the teacher do (all through widgets, no CLI):
1. Move a slider to choose K (number of neighbors).
2. Click "Train & Evaluate" -> the model is trained on 70% of the data
   and tested on the remaining 30%. Accuracy + a confusion matrix plot
   are shown.
3. Type 4 flower measurements and click "Predict" -> the GUI shows the
   predicted species using the currently trained model.
"""

import tkinter as tk
from tkinter import ttk, messagebox

import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.preprocessing import StandardScaler

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


class KNNApp:
    def __init__(self, parent):
        self.win = tk.Toplevel(parent)
        self.win.title("Experiment 1: KNN Classifier (Iris Dataset)")
        self.win.geometry("780x640")

        # ---- Step 1: Load dataset (done once, in memory) ----
        self.data = load_iris()
        self.X = self.data.data
        self.y = self.data.target
        self.target_names = self.data.target_names
        self.feature_names = self.data.feature_names

        self.scaler = StandardScaler()
        self.model = None

        self._build_widgets()

    # ---------------------------------------------------------------
    def _build_widgets(self):
        top = tk.Frame(self.win)
        top.pack(fill="x", padx=15, pady=10)

        tk.Label(top, text="K (number of neighbors):", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, sticky="w"
        )
        self.k_var = tk.IntVar(value=5)
        self.k_slider = tk.Scale(
            top, from_=1, to=15, orient="horizontal", variable=self.k_var, length=250
        )
        self.k_slider.grid(row=0, column=1, padx=10)

        train_btn = ttk.Button(top, text="Train & Evaluate", command=self.train_and_evaluate)
        train_btn.grid(row=0, column=2, padx=10)

        self.result_label = tk.Label(self.win, text="Train the model to see accuracy here.",
                                      font=("Segoe UI", 10), fg="#333333")
        self.result_label.pack(pady=5)

        # Plot area (confusion matrix)
        self.plot_frame = tk.Frame(self.win)
        self.plot_frame.pack(fill="both", expand=True, padx=15, pady=5)

        # Prediction area
        pred_frame = tk.LabelFrame(self.win, text="Predict a new flower", padx=10, pady=10)
        pred_frame.pack(fill="x", padx=15, pady=10)

        self.feature_vars = []
        defaults = [5.1, 3.5, 1.4, 0.2]
        for i, fname in enumerate(self.feature_names):
            tk.Label(pred_frame, text=fname + ":").grid(row=0, column=2 * i, sticky="w", padx=3)
            var = tk.DoubleVar(value=defaults[i])
            entry = tk.Entry(pred_frame, textvariable=var, width=6)
            entry.grid(row=0, column=2 * i + 1, padx=3)
            self.feature_vars.append(var)

        predict_btn = ttk.Button(pred_frame, text="Predict", command=self.predict_new)
        predict_btn.grid(row=1, column=0, columnspan=8, pady=8)

        self.prediction_label = tk.Label(pred_frame, text="Prediction: -", font=("Segoe UI", 11, "bold"))
        self.prediction_label.grid(row=2, column=0, columnspan=8)

    # ---------------------------------------------------------------
    def train_and_evaluate(self):
        k = self.k_var.get()

        # Step 2: train/test split
        X_train, X_test, y_train, y_test = train_test_split(
            self.X, self.y, test_size=0.3, random_state=42, stratify=self.y
        )

        # Step 3: scale features (KNN is distance based, scaling matters)
        X_train_s = self.scaler.fit_transform(X_train)
        X_test_s = self.scaler.transform(X_test)

        # Step 4: train KNN
        self.model = KNeighborsClassifier(n_neighbors=k)
        self.model.fit(X_train_s, y_train)

        # Step 5: evaluate
        y_pred = self.model.predict(X_test_s)
        acc = accuracy_score(y_test, y_pred)
        cm = confusion_matrix(y_test, y_pred)

        self.result_label.config(
            text=f"K = {k}  |  Test Accuracy = {acc * 100:.2f}%  (test size = {len(y_test)} samples)"
        )

        self._plot_confusion_matrix(cm)

    def _plot_confusion_matrix(self, cm):
        for widget in self.plot_frame.winfo_children():
            widget.destroy()

        fig, ax = plt.subplots(figsize=(5, 4))
        im = ax.imshow(cm, cmap="Blues")
        ax.set_xticks(range(len(self.target_names)))
        ax.set_yticks(range(len(self.target_names)))
        ax.set_xticklabels(self.target_names)
        ax.set_yticklabels(self.target_names)
        ax.set_xlabel("Predicted label")
        ax.set_ylabel("True label")
        ax.set_title("Confusion Matrix")
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                        color="white" if cm[i, j] > cm.max() / 2 else "black")
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        plt.close(fig)

    def predict_new(self):
        if self.model is None:
            messagebox.showwarning("Not trained", "Please click 'Train & Evaluate' first.")
            return
        try:
            values = np.array([[v.get() for v in self.feature_vars]])
        except tk.TclError:
            messagebox.showerror("Invalid input", "Please enter numeric values.")
            return

        values_s = self.scaler.transform(values)
        pred = self.model.predict(values_s)[0]
        self.prediction_label.config(text=f"Prediction: {self.target_names[pred]}")


def open_window(parent):
    KNNApp(parent)
