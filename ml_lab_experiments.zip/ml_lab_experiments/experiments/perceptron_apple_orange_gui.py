"""
perceptron_apple_orange_gui.py
-------------------------------
Experiment 5: Perceptron - Apple vs Orange Recognition
(Classic example from Hagan, "Neural Network Design", Chapter 4)

The sensor produces two measurements for a fruit:
    shape   : +1 = round        , -1 = elliptical/oval
    texture : +1 = smooth       , -1 = rough / textured

Training patterns (as in Hagan's textbook example):
    Orange -> shape = -1, texture = -1   -> target = -1
    Apple  -> shape = +1, texture = +1   -> target = +1

The GUI lets the teacher:
1. Click "Train Perceptron (from scratch)" -> the perceptron learning
   rule (W_new = W_old + e*p^T, b_new = b_old + e) runs iteration by
   iteration on the two training patterns above; every step is printed
   in the log box, and the final weights/bias are displayed.
2. Choose a new fruit's shape and texture using radio buttons and
   click "Classify" -> the trained perceptron's hard-limit output
   decides Apple or Orange.
"""

import tkinter as tk
from tkinter import ttk

import numpy as np


class PerceptronApp:
    def __init__(self, parent):
        self.win = tk.Toplevel(parent)
        self.win.title("Experiment 5: Perceptron - Apple vs Orange (Hagan Ch.4)")
        self.win.geometry("620x620")

        # Training data (Hagan's classic apple/orange example)
        # p1 = orange (shape=-1, texture=-1), target = -1
        # p2 = apple  (shape=+1, texture=+1), target = +1
        self.P = np.array([[-1, -1], [1, 1]])   # each row is a pattern [shape, texture]
        self.T = np.array([-1, 1])              # -1 = orange, +1 = apple

        self.W = np.array([0.0, 0.0])
        self.b = 0.0
        self.trained = False

        self._build_widgets()

    def _build_widgets(self):
        info = tk.Label(
            self.win,
            text=("Perceptron classifies a fruit using two sensor readings:\n"
                  "Shape (+1 = round, -1 = oval)   and   Texture (+1 = smooth, -1 = rough)\n"
                  "Training data:  Orange = (-1,-1) -> target -1   |   Apple = (1,1) -> target +1"),
            font=("Segoe UI", 9), justify="left", fg="#333333"
        )
        info.pack(padx=15, pady=10, anchor="w")

        train_btn = ttk.Button(self.win, text="Train Perceptron (from scratch)", command=self.train)
        train_btn.pack(pady=5)

        self.log_box = tk.Text(self.win, height=16, width=70, font=("Consolas", 9))
        self.log_box.pack(padx=15, pady=5)

        self.weights_label = tk.Label(self.win, text="Weights: not trained yet",
                                       font=("Segoe UI", 10, "bold"))
        self.weights_label.pack(pady=5)

        # ---- Classification section ----
        classify_frame = tk.LabelFrame(self.win, text="Classify a new fruit", padx=10, pady=10)
        classify_frame.pack(fill="x", padx=15, pady=15)

        tk.Label(classify_frame, text="Shape:").grid(row=0, column=0, sticky="w")
        self.shape_var = tk.IntVar(value=1)
        tk.Radiobutton(classify_frame, text="Round (+1)", variable=self.shape_var, value=1).grid(row=0, column=1)
        tk.Radiobutton(classify_frame, text="Oval (-1)", variable=self.shape_var, value=-1).grid(row=0, column=2)

        tk.Label(classify_frame, text="Texture:").grid(row=1, column=0, sticky="w")
        self.texture_var = tk.IntVar(value=1)
        tk.Radiobutton(classify_frame, text="Smooth (+1)", variable=self.texture_var, value=1).grid(row=1, column=1)
        tk.Radiobutton(classify_frame, text="Rough (-1)", variable=self.texture_var, value=-1).grid(row=1, column=2)

        classify_btn = ttk.Button(classify_frame, text="Classify", command=self.classify)
        classify_btn.grid(row=2, column=0, columnspan=3, pady=10)

        self.result_label = tk.Label(classify_frame, text="Result: -", font=("Segoe UI", 12, "bold"))
        self.result_label.grid(row=3, column=0, columnspan=3)

    def _hardlim(self, n):
        # Hagan's hard-limit activation function: 1 if n >= 0 else -1
        return 1 if n >= 0 else -1

    def train(self):
        self.log_box.delete("1.0", tk.END)
        self.W = np.array([0.0, 0.0])
        self.b = 0.0

        self.log_box.insert(tk.END, "Initial weights W = [0, 0], bias b = 0\n")
        self.log_box.insert(tk.END, "-" * 55 + "\n")

        max_epochs = 10
        for epoch in range(1, max_epochs + 1):
            all_correct = True
            self.log_box.insert(tk.END, f"Epoch {epoch}:\n")
            for p, t in zip(self.P, self.T):
                n = np.dot(self.W, p) + self.b
                a = self._hardlim(n)
                e = t - a  # error: -2, 0, or +2

                self.log_box.insert(
                    tk.END,
                    f"  pattern p={p.tolist()}, target t={t:+d} -> net n={n:.2f}, "
                    f"output a={a:+d}, error e={e:+d}\n"
                )

                if e != 0:
                    all_correct = False
                    self.W = self.W + e * p
                    self.b = self.b + e
                    self.log_box.insert(
                        tk.END, f"    -> update: W = {self.W.tolist()}, b = {self.b}\n"
                    )
            if all_correct:
                self.log_box.insert(tk.END, f"\nConverged after epoch {epoch} (no errors).\n")
                break

        self.trained = True
        self.weights_label.config(text=f"Final Weights: W = {self.W.tolist()}, bias b = {self.b}")
        self.log_box.see(tk.END)

    def classify(self):
        if not self.trained:
            self.train()

        shape = self.shape_var.get()
        texture = self.texture_var.get()
        p = np.array([shape, texture])
        n = np.dot(self.W, p) + self.b
        a = self._hardlim(n)

        label = "Apple" if a == 1 else "Orange"
        self.result_label.config(text=f"Result: net = {n:.2f}  ->  Classified as: {label}")


def open_window(parent):
    PerceptronApp(parent)
