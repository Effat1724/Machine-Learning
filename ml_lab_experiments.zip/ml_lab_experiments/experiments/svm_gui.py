"""
svm_gui.py
----------
Experiment 2: Support Vector Machine (SVM) classification on the Iris
dataset, using two features (petal length, petal width) so the decision
boundary can be drawn in 2D.

What the GUI lets the teacher do:
1. Pick a kernel (linear / rbf / poly) from a dropdown.
2. Type a value for C (regularization strength).
3. Click "Train & Plot Boundary" -> the trained SVM's decision regions
   are drawn together with the data points, plus accuracy.
4. Type petal length & width for a new sample and click "Predict".
"""

import tkinter as tk
from tkinter import ttk, messagebox

import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.colors import ListedColormap


class SVMApp:
    def __init__(self, parent):
        self.win = tk.Toplevel(parent)
        self.win.title("Experiment 2: SVM Classifier (Iris Dataset)")
        self.win.geometry("780x680")

        data = load_iris()
        # Use only petal length & petal width (columns 2, 3) -> easy to plot in 2D
        self.X = data.data[:, 2:4]
        self.y = data.target
        self.target_names = data.target_names
        self.feature_names = [data.feature_names[2], data.feature_names[3]]
        self.model = None

        self._build_widgets()

    def _build_widgets(self):
        top = tk.Frame(self.win)
        top.pack(fill="x", padx=15, pady=10)

        tk.Label(top, text="Kernel:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w")
        self.kernel_var = tk.StringVar(value="rbf")
        kernel_menu = ttk.Combobox(top, textvariable=self.kernel_var,
                                    values=["linear", "rbf", "poly"], width=10, state="readonly")
        kernel_menu.grid(row=0, column=1, padx=10)

        tk.Label(top, text="C (regularization):", font=("Segoe UI", 10, "bold")).grid(row=0, column=2, sticky="w")
        self.c_var = tk.DoubleVar(value=1.0)
        c_entry = tk.Entry(top, textvariable=self.c_var, width=8)
        c_entry.grid(row=0, column=3, padx=10)

        train_btn = ttk.Button(top, text="Train & Plot Boundary", command=self.train_and_plot)
        train_btn.grid(row=0, column=4, padx=10)

        self.result_label = tk.Label(self.win, text="Train the model to see accuracy here.",
                                      font=("Segoe UI", 10), fg="#333333")
        self.result_label.pack(pady=5)

        self.plot_frame = tk.Frame(self.win)
        self.plot_frame.pack(fill="both", expand=True, padx=15, pady=5)

        pred_frame = tk.LabelFrame(self.win, text="Predict a new flower (petal length & width)", padx=10, pady=10)
        pred_frame.pack(fill="x", padx=15, pady=10)

        tk.Label(pred_frame, text=self.feature_names[0] + ":").grid(row=0, column=0, sticky="w")
        self.f1_var = tk.DoubleVar(value=1.4)
        tk.Entry(pred_frame, textvariable=self.f1_var, width=8).grid(row=0, column=1, padx=5)

        tk.Label(pred_frame, text=self.feature_names[1] + ":").grid(row=0, column=2, sticky="w")
        self.f2_var = tk.DoubleVar(value=0.2)
        tk.Entry(pred_frame, textvariable=self.f2_var, width=8).grid(row=0, column=3, padx=5)

        predict_btn = ttk.Button(pred_frame, text="Predict", command=self.predict_new)
        predict_btn.grid(row=0, column=4, padx=10)

        self.prediction_label = tk.Label(pred_frame, text="Prediction: -", font=("Segoe UI", 11, "bold"))
        self.prediction_label.grid(row=1, column=0, columnspan=5, pady=8)

    def train_and_plot(self):
        try:
            C = float(self.c_var.get())
        except (tk.TclError, ValueError):
            messagebox.showerror("Invalid input", "C must be a number.")
            return
        kernel = self.kernel_var.get()

        X_train, X_test, y_train, y_test = train_test_split(
            self.X, self.y, test_size=0.3, random_state=42, stratify=self.y
        )

        self.model = SVC(kernel=kernel, C=C)
        self.model.fit(X_train, y_train)

        y_pred = self.model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        self.result_label.config(
            text=f"Kernel = {kernel}, C = {C}  |  Test Accuracy = {acc * 100:.2f}%"
        )

        self._plot_decision_boundary()

    def _plot_decision_boundary(self):
        for widget in self.plot_frame.winfo_children():
            widget.destroy()

        x_min, x_max = self.X[:, 0].min() - 0.5, self.X[:, 0].max() + 0.5
        y_min, y_max = self.X[:, 1].min() - 0.5, self.X[:, 1].max() + 0.5
        xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200), np.linspace(y_min, y_max, 200))
        Z = self.model.predict(np.c_[xx.ravel(), yy.ravel()])
        Z = Z.reshape(xx.shape)

        cmap_light = ListedColormap(["#FFDDDD", "#DDFFDD", "#DDDDFF"])
        cmap_bold = ["#FF0000", "#00AA00", "#0000FF"]

        fig, ax = plt.subplots(figsize=(5.5, 4.5))
        ax.contourf(xx, yy, Z, cmap=cmap_light, alpha=0.8)
        for idx, name in enumerate(self.target_names):
            mask = self.y == idx
            ax.scatter(self.X[mask, 0], self.X[mask, 1], c=cmap_bold[idx], label=name,
                       edgecolor="k", s=30)
        ax.set_xlabel(self.feature_names[0])
        ax.set_ylabel(self.feature_names[1])
        ax.set_title("SVM Decision Boundary")
        ax.legend()
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        plt.close(fig)

    def predict_new(self):
        if self.model is None:
            messagebox.showwarning("Not trained", "Please click 'Train & Plot Boundary' first.")
            return
        try:
            sample = np.array([[self.f1_var.get(), self.f2_var.get()]])
        except tk.TclError:
            messagebox.showerror("Invalid input", "Please enter numeric values.")
            return
        pred = self.model.predict(sample)[0]
        self.prediction_label.config(text=f"Prediction: {self.target_names[pred]}")


def open_window(parent):
    SVMApp(parent)
