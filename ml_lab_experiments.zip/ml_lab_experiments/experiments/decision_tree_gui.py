"""
decision_tree_gui.py
---------------------
Experiment 4: Decision Tree classification on the Iris dataset.

What the GUI lets the teacher do:
1. Choose max tree depth with a slider.
2. Click "Train & Show Tree" -> the tree is trained, accuracy is shown,
   and the tree structure is drawn (a diagram, not text) so the teacher
   can see exactly how it splits.
3. Type 4 flower measurements and click "Predict".
"""

import tkinter as tk
from tkinter import ttk, messagebox

import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


class DecisionTreeApp:
    def __init__(self, parent):
        self.win = tk.Toplevel(parent)
        self.win.title("Experiment 4: Decision Tree Classifier (Iris Dataset)")
        self.win.geometry("820x700")

        data = load_iris()
        self.X = data.data
        self.y = data.target
        self.target_names = data.target_names
        self.feature_names = data.feature_names
        self.model = None

        self._build_widgets()

    def _build_widgets(self):
        top = tk.Frame(self.win)
        top.pack(fill="x", padx=15, pady=10)

        tk.Label(top, text="Max Depth:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w")
        self.depth_var = tk.IntVar(value=3)
        tk.Scale(top, from_=1, to=8, orient="horizontal", variable=self.depth_var,
                 length=220).grid(row=0, column=1, padx=10)

        train_btn = ttk.Button(top, text="Train & Show Tree", command=self.train_and_plot)
        train_btn.grid(row=0, column=2, padx=10)

        self.result_label = tk.Label(self.win, text="Train the model to see accuracy here.",
                                      font=("Segoe UI", 10), fg="#333333")
        self.result_label.pack(pady=5)

        self.plot_frame = tk.Frame(self.win)
        self.plot_frame.pack(fill="both", expand=True, padx=15, pady=5)

        pred_frame = tk.LabelFrame(self.win, text="Predict a new flower", padx=10, pady=10)
        pred_frame.pack(fill="x", padx=15, pady=10)

        self.feature_vars = []
        defaults = [5.1, 3.5, 1.4, 0.2]
        for i, fname in enumerate(self.feature_names):
            tk.Label(pred_frame, text=fname + ":").grid(row=0, column=2 * i, sticky="w", padx=3)
            var = tk.DoubleVar(value=defaults[i])
            tk.Entry(pred_frame, textvariable=var, width=6).grid(row=0, column=2 * i + 1, padx=3)
            self.feature_vars.append(var)

        predict_btn = ttk.Button(pred_frame, text="Predict", command=self.predict_new)
        predict_btn.grid(row=1, column=0, columnspan=8, pady=8)

        self.prediction_label = tk.Label(pred_frame, text="Prediction: -", font=("Segoe UI", 11, "bold"))
        self.prediction_label.grid(row=2, column=0, columnspan=8)

    def train_and_plot(self):
        depth = self.depth_var.get()

        X_train, X_test, y_train, y_test = train_test_split(
            self.X, self.y, test_size=0.3, random_state=42, stratify=self.y
        )

        self.model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        self.model.fit(X_train, y_train)

        y_pred = self.model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        self.result_label.config(text=f"Max Depth = {depth}  |  Test Accuracy = {acc * 100:.2f}%")

        self._plot_tree()

    def _plot_tree(self):
        for widget in self.plot_frame.winfo_children():
            widget.destroy()

        fig, ax = plt.subplots(figsize=(7, 5))
        plot_tree(self.model, feature_names=self.feature_names, class_names=self.target_names,
                  filled=True, rounded=True, fontsize=8, ax=ax)
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        plt.close(fig)

    def predict_new(self):
        if self.model is None:
            messagebox.showwarning("Not trained", "Please click 'Train & Show Tree' first.")
            return
        try:
            values = np.array([[v.get() for v in self.feature_vars]])
        except tk.TclError:
            messagebox.showerror("Invalid input", "Please enter numeric values.")
            return
        pred = self.model.predict(values)[0]
        self.prediction_label.config(text=f"Prediction: {self.target_names[pred]}")


def open_window(parent):
    DecisionTreeApp(parent)
